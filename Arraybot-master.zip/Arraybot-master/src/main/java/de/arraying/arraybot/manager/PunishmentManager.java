package de.arraying.arraybot.manager;

import de.arraying.arraybot.data.database.categories.GuildEntry;
import de.arraying.arraybot.data.database.core.Category;
import de.arraying.arraybot.data.database.templates.SetEntry;
import de.arraying.arraybot.language.Message;
import de.arraying.arraybot.punishment.PunishmentObject;
import de.arraying.arraybot.punishment.PunishmentType;
import de.arraying.arraybot.util.*;
import de.arraying.arraybot.util.objects.Pair;
import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.entities.TextChannel;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;

/**
 * Copyright 2017 Arraying
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
public final class PunishmentManager {

    private final ScheduledExecutorService executor = Executors.newScheduledThreadPool(15);

    /**
     * Creates a new punishment.
     * @param guild The guild in which the punishment occurred.
     * @param punished The punished user.
     * @param type The punishment type.
     * @param staff The staff member.
     * @param viaAudit Whether or not the punishment has already occurred and the manager is just handling the result.
     * @param expiration The time, in milliseconds, when the punishment will expire.
     * @param reason The reason for the punishment.
     * @return True if the punishment was successful, false if it was not.
     */
    public boolean punish(Guild guild, long punished, PunishmentType type, long staff, long expiration, boolean viaAudit, String reason) {
        reason = reason == null ? Message.PUNISH_EMBED_REASON_DEFAULT.getContent(guild.getIdLong()) : reason;
        Boolean revocation = null;
        if(!viaAudit) {
            Pair<Boolean, Boolean> result = type.getPunishment().punish(guild, punished, reason);
            if(!result.getA()) {
                return false;
            }
            revocation = result.getB();
        }
        long guildId = guild.getIdLong();
        GuildEntry guildEntry = (GuildEntry) Category.GUILD.getEntry();
        int old = Integer.valueOf(guildEntry.fetch(guildEntry.getField(GuildEntry.Fields.COUNT_PUNISHMENT), guildId, null));
        boolean revoke = revocation == null ? type == PunishmentType.KICK : revocation;
        PunishmentObject punishmentObject = new PunishmentObject(++old, punished, type, staff, expiration, revoke, reason);
        punishmentObject.toRedis(guild);
        schedulePunishmentRevocation(guild, punishmentObject);
        log(guild, punishmentObject, false, null);
        return true;
    }

    /**
     * Schedules the punishment revocation.
     * @param guild The guild.
     * @param punishmentObject The punishment object.
     */
    void schedulePunishmentRevocation(Guild guild, PunishmentObject punishmentObject) {
        if(punishmentObject.isRevoked()) {
            return;
        }
        if(punishmentObject.getType() != PunishmentType.TEMP_MUTE
                && punishmentObject.getType() != PunishmentType.TEMP_BAN) {
            return;
        }
        long expiration = punishmentObject.getExpiration();
        long current = System.currentTimeMillis();
        if(expiration <= 0) {
            return;
        }
        if(expiration <= current) {
            //noinspection ResultOfMethodCallIgnored
            revoke(guild, punishmentObject, null);
            return;
        }
        executor.schedule(() -> {
            if(!punishmentObject.isRevoked()) {
                revoke(guild, punishmentObject, null);
            }
        }, (expiration - current), TimeUnit.MILLISECONDS);
    }

    /**
     * Revokes a punishment.
     * @param guild The guild in which the punishment occurred.
     * @param punishmentObject The punishment.
     * @param revoker The person who revoked this punishment, can be null if automatic.
     * @return True if the revocation was successful, false otherwise.
     */
    public boolean revoke(Guild guild, PunishmentObject punishmentObject, Long revoker) {
        boolean success = punishmentObject.getType().getPunishment().revoke(guild, punishmentObject.getUser());
        if(!success) {
            return false;
        }
        punishmentObject.revoke();
        punishmentObject.toRedis(guild);
        log(guild, punishmentObject, true, revoker);
        return true;
    }

    /**
     * Gets all punishments for a guild.
     * @param guild The guild.
     * @return A list of all punishments.
     */
    public List<PunishmentObject> getAllPunishments(Guild guild) {
        long guildId = guild.getIdLong();
        SetEntry entry = (SetEntry) Category.PUNISHMENT_IDS.getEntry();
        List<PunishmentObject> punishments = new ArrayList<>();
        for(String punishment : entry.values(guildId)) {
            punishments.add(PunishmentObject.fromRedis(guild, Integer.valueOf(punishment)));
        }
        return punishments;
    }

    /**
     * Gets a specific punishment based on a filter.
     * @param guild The guild.
     * @param filter The filter.
     * @return A punishment, or null.
     */
    public PunishmentObject getSpecificPunishment(Guild guild, Predicate<? super PunishmentObject> filter) {
        return getAllPunishments(guild).stream()
                .filter(filter)
                .findFirst()
                .orElse(null);
    }

    /**
     * Get the punishment embed.
     * @param guild The guild in which the punishment was invoked.
     * @param punishmentObject The punishment itself.
     * @param onRevoke If the punishment is being revoked.
     * @param revoker The person who revoked, null if it is not being revoked.
     * @return The embed.
     */
    public CustomEmbedBuilder getEmbed(Guild guild, PunishmentObject punishmentObject, boolean onRevoke, Long revoker) {
        long guildId = guild.getIdLong();
        String punishmentType;
        if(onRevoke) {
            switch(punishmentObject.getType()) {
                case TEMP_BAN:
                case BAN:
                    punishmentType = Message.PUNISH_TYPE_UNBAN.getContent(guildId);
                    break;
                case TEMP_MUTE:
                case MUTE:
                    punishmentType = Message.PUNISH_TYPE_UNMUTE.getContent(guild.getIdLong());
                    break;
                default:
                    punishmentType = Message.PUNISH_TYPE_UNKNOWN.getContent(guild.getIdLong());
            }
        } else {
            punishmentType = punishmentObject.getType().getName().getContent(guild.getIdLong());
        }
        CustomEmbedBuilder embed = UEmbed.getEmbed(guild)
                .setAuthor(Message.PUNISH_EMBED_TITLE.getContent(guild.getIdLong(), punishmentType, String.valueOf(punishmentObject.getId())), null, null)
                .addField(Message.PUNISH_EMBED_USER.getContent(guildId),
                        UUser.asMention(punishmentObject.getUser()),
                        false)
                .addField(Message.PUNISH_EMBED_STAFF.getContent(guildId),
                        onRevoke ?
                                revoker == null ?
                                        Message.PUNISH_EMBED_AUTOMATIC.getContent(guildId) :
                                        revoker == UDefaults.DEFAULT_UNKNOWN_SNOWFLAKE ? Message.PUNISH_EMBED_UNKNOWN.getContent(guildId) :
                                                UUser.asMention(revoker)
                                :
                                UUser.asMention(punishmentObject.getStaff()),
                        false);
        if(!onRevoke) {
            embed.addField(Message.PUNISH_EMBED_REASON.getContent(guildId),
                    punishmentObject.getReason(),
                    false);
            if(punishmentObject.getExpiration() > 0) {
                embed.addField(Message.PUNISH_EMBED_EXPIRATION.getContent(guildId),
                        UTime.getDisplayableTime(guild, punishmentObject.getExpiration()),
                        false)
                        .setFooter(Message.PUNISH_EMBED_EXPIRATION_FOOTER.getContent(guildId), null);
            }
        }
        return embed;
    }

    /**
     * Logs the punishment into a logging channel.
     * @param guild The guild.
     * @param punishmentObject The punishment.
     * @param onRevoke If this log occurred during the revocation.
     * @param revoker The person who revoked this punishment, can be null if automatic or not revoked.
     */
    private void log(Guild guild, PunishmentObject punishmentObject, boolean onRevoke, Long revoker) {
        GuildEntry entry = (GuildEntry) Category.GUILD.getEntry();
        long channelId = Long.valueOf(entry.fetch(entry.getField(GuildEntry.Fields.PUNISHMENT_CHANNEL), guild.getIdLong(), null));
        TextChannel channel = guild.getTextChannelById(channelId);
        if(channel == null
                || UChannel.cantTalk(channel)) {
            return;
        }
        CustomEmbedBuilder embed = getEmbed(guild, punishmentObject, onRevoke, revoker);
        channel.sendMessage(embed.build()).queue();
    }

}
